# SOROSH Programmer Firewall

یک اسکریپت حرفه‌ای برای بلاک کردن IPهای ایران و حفاظت از سرور.
Reality VPN روی پورت 443 سالم می‌ماند.

---

## ⚡ اجرای مستقیم
برای نصب و اجرای سریع کافیست روی سرور بزنید:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/SOROSH-Programmer/THESOROSH/main/install.sh)
```

> این دستور کل اسکریپت را دانلود و اجرا می‌کند بدون نیاز به ساخت فایل دستی.

---

## 🧩 توضیح اسکریپت
- **ipset**: ساخت مجموعه IPهای ایران
- **iptables**: بلاک کردن NEW connection به ایران، اجازه دادن به 443
- **atomic swap**: بدون وقفه در اتصال‌های فعال
- **netfilter-persistent**: ذخیره rules بعد از ریبوت

---

## 🔍 تست اجرا
### بررسی لیست IP های ایران
```bash
ipset list iran | head
```
> نمایش ۱۰ مورد اول برای تست سریع.

### تست بلاک شدن ایران
```bash
curl http://91.98.0.1 --max-time 5
```
> اتصال به IP ایران باید تایم‌اوت بده.

### تست اتصال خارجی (Reality و اینترنت)
```bash
curl https://google.com --max-time 5
```
> باید جواب بده، یعنی Reality سالم است.

---

## 🕒 آپدیت خودکار
برای آپدیت روزانه لیست ایران:
```bash
crontab -e
```
اضافه کنید:
```
0 4 * * * /root/install.sh
```
> هر روز ساعت ۴ صبح لیست ایران آپدیت می‌شود.

---

## ⚠️ مدیریت بلاک‌ها
### غیرفعال کردن بلاک ایران
```bash
iptables -D OUTPUT -m set --match-set iran dst -m conntrack --ctstate NEW -j REJECT
```

### حذف کامل ipset ایران
```bash
ipset destroy iran
```

### ذخیره تغییرات
```bash
netfilter-persistent save
```
> حفظ تغییرات iptables و ipset بعد از ریبوت.

---

## ⚖ License
MIT License